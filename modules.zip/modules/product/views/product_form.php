<script src="<?php echo base_url() ?>my-assets/js/admin_js/json/product.js" type="text/javascript"></script>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-bd lobidrag">
            <div class="panel-heading">
                <div class="panel-title">
                    <h4><?php echo $title; ?></h4>
                </div>
            </div>
			
			 <div class="panel-body">
			 
            <?php echo form_open_multipart('product_form/'.$id, array('class' => 'form-vertical', 'id' => 'insert_product', 'name' => 'insert_product')) ?>
         
                <?php if(empty($id)){?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="barcode_or_qrcode"
                                class="col-sm-2 col-form-label"><?php echo display('barcode_or_qrcode') ?> <i
                                    class="text-danger"></i></label>
                            <div class="col-sm-10">
                                <input class="form-control" name="product_id" type="text" id="product_id"
                                    placeholder="<?php echo display('barcode_or_qrcode') ?>" tabindex="1">
                            </div>
                        </div>
                    </div>
                </div>
                <?php }?>

                  	
			  <div class="form-group row">
                    <label for="company_id" class="col-sm-2 col-form-label">Company Name:<i class="text-danger">*</i></label>
                    <div class="col-sm-10">
                        <select name="company_id" id="company_id" class="form-control" required tabindex="2">
                            <option value="">Select Company</option>
                            <?php if (!empty($companies)) { ?>
                                <?php foreach ($companies as $company) { ?>
                                    <option value="<?php echo $company->company_id; ?>" 
                                        <?php echo (!empty($product->company_id) && $product->company_id == $company->company_id) ? 'selected' : ''; ?>>
                                        <?php echo $company->company_name; ?>
                                    </option>
                                <?php } ?>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <!-- Supplier Dropdown -->
                <div class="form-group row">
                    <label for="supplier_id" class="col-sm-2 col-form-label"><?php echo display('supplier') ?><i class="text-danger">*</i></label>
                    <div class="col-sm-10">
                        <select name="supplier_id[]" id="supplier_id" class="form-control" required>
                            <option value=""><?php echo display('select_one') ?></option>
                            <?php if (!empty($supplier)) { ?>
                                <?php foreach ($supplier as $suppliers) { ?>
                                    <option value="<?php echo $suppliers['supplier_id'] ?>"
                                        <?php echo (!empty($supplier_pr[0]['supplier_id']) && $supplier_pr[0]['supplier_id'] == $suppliers['supplier_id']) ? 'selected' : ''; ?>>
                                        <?php echo $suppliers['supplier_name'] ?>
                                    </option>
                                <?php } ?>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                   <!-- Product Name and Serial No -->
                <div class="form-group row">
                    <label for="product_name" class="col-sm-2 col-form-label"><?php echo display('product_name') ?> <i class="text-danger">*</i></label>
                    <div class="col-sm-4">
                        <input class="form-control" name="product_name" type="text" id="product_name"
                            placeholder="<?php echo display('product_name') ?>" 
                            value="<?php echo $product->product_name ?>" required tabindex="3">
                    </div>

                    <label for="serial_no" class="col-sm-2 col-form-label"><?php echo display('serial_no') ?></label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" id="serial_no" name="serial_no"
                            placeholder="111,abc,XYz" value="<?php echo $product->serial_no ?>" tabindex="4">
                    </div>
                </div>


            

                 <!-- Category and Product Model -->
                <div class="form-group row">
                    <label for="category_id" class="col-sm-2 col-form-label"><?php echo display('category') ?><i class="text-danger">*</i></label>
                    <div class="col-sm-4">
                        <select class="form-control" id="category_id" required name="category_id" tabindex="5">
                            <option value=""></option>
                            <?php if (!empty($category_list)) { ?>
                                <?php foreach ($category_list as $categories) { ?>
                                    <option value="<?php echo $categories['category_id'] ?>" 
                                        <?php echo ($product->category_id == $categories['category_id']) ? 'selected' : ''; ?>>
                                        <?php echo $categories['category_name'] ?>
                                    </option>
                                <?php } ?>
                            <?php } ?>
                        </select>
                    </div>

                    <label for="product_model" class="col-sm-2 col-form-label"><?php echo display('model') ?></label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" id="product_model" name="model" 
                            placeholder="<?php echo display('model') ?>" 
                            value="<?php echo $product->product_model ?>" tabindex="6">
                    </div>
                </div>


 <!-- Unit and Box Size -->
                <div class="form-group row">
                    <label for="unit" class="col-sm-2 col-form-label"><?php echo display('unit') ?></label>
                    <div class="col-sm-4">
                        <select class="form-control" id="unit" name="unit" tabindex="7">
                            <option value="">Select One</option>
                            <?php if (!empty($unit_list)) { ?>
                                <?php foreach ($unit_list as $units) { ?>
                                    <option value="<?php echo $units['unit_name'] ?>" 
                                        <?php echo ($product->unit == $units['unit_name']) ? 'selected' : ''; ?>>
                                        <?php echo $units['unit_name'] ?>
                                    </option>
                                <?php } ?>
                            <?php } ?>
                        </select>
                    </div>

                    <!-- <label for="box_size" class="col-sm-2 col-form-label">Box Size</label>
                    <div class="col-sm-4">
                        <input class="form-control text-right" id="box_size" name="box_size" type="text"
                            value="1<?php //echo $product->box_size ?? 1 ?>" readonly tabindex="8">
                    </div>-->
                </div>
				
				
				  <!-- Sell Price and Cost Price -->
                <div class="form-group row">
                      <?php if(empty($supplier_pr)){?>
                  
                      
                              <label for="cost_price" class="col-sm-2 col-form-label"><?php echo display('cost_price') ?>
                                </label>
                            <div class="col-sm-4">
                                <input class="form-control text-right" id="cost_price" name="supplier_price" type="text"
                                     placeholder="0.00" tabindex="5" min="0">
                            </div>
                   
                    <?php }else{
                    foreach($supplier_pr as $supplier_product){
                    ?>
                 
                      
                             <label for="cost_price" class="col-sm-2 col-form-label"><?php echo display('cost_price') ?>
                                </label>
                            <div class="col-sm-4">
                                <input class="form-control text-right" id="cost_price" name="supplier_price" type="text"
                                     placeholder="0.00" tabindex="5" min="0"
                                    value="<?php echo $supplier_product['supplier_price']?>">
                            </div>
                     
                  
                    <?php }}?>
					
					
					 <label for="sell_price" class="col-sm-2 col-form-label"><?php echo display('sell_price') ?>
                                </label>
                            <div class="col-sm-4">
                                <input class="form-control text-right" id="sell_price" name="price" type="text"
                                   placeholder="0.00" tabindex="5" min="0"
                                    value="<?php echo $product->price?>">
                            </div>
                </div>
				
				  <!-- Unit Sell Price and Unit Cost Price -->
               <!-- <div class="form-group row">
				
				 <label for="unit_cost_price" class="col-sm-2 col-form-label">Unit Cost Price</label>
                    <div class="col-sm-4">
                        <input class="form-control text-right" id="unit_cost_price" type="text" name="unit_cost_price" readonly placeholder="0">
                    </div>
					
                    <label for="unit_sell_price" class="col-sm-2 col-form-label">Unit Sell Price</label>
                    <div class="col-sm-4">
                        <input class="form-control text-right" id="unit_sell_price" type="text" name="unit_sell_price" readonly placeholder="0">
                    </div>

                   
                </div>-->

                  <!-- Product Details -->
                <div class="form-group row">
                    <label for="description" class="col-sm-2 col-form-label"><?php echo display('product_details') ?></label>
                    <div class="col-sm-10">
                        <textarea class="form-control" name="description" id="description" rows="3" 
                            placeholder="<?php echo display('product_details') ?>" tabindex="12">
                            <?php echo $product->product_details ?>
                        </textarea>
                    </div>
                </div>

                    <!-- Image Upload -->
                <div class="form-group row">
                    <label for="image" class="col-sm-2 col-form-label"><?php echo display('image') ?></label>
                    <div class="col-sm-4">
                        <input type="file" name="image" class="form-control" id="image" tabindex="13">
                        <input type="hidden" name="old_image" value="<?php echo $product->image ?>">
                    </div>
                    <?php if (!empty($product->image)) { ?>
                    <div class="col-sm-6">
                        <img src="<?php echo base_url() . $product->image ?>" alt="Product Image" class="img-thumbnail" width="100">
                    </div>
                    <?php } ?>
                </div>

             
               
                    
                    <div class="form-group row <?php if($vattaxinfo->fixed_tax != 1){echo 'hidden';}?>>
                      
                            <label for="serial_no" class="col-sm-2 col-form-label"><?php  display('product_vat').' %' ?> </label>
                            <div class="col-sm-4">
                                <input type="text" tabindex="14" class="form-control " id="product_vat" name="product_vat"
                                    placeholder="<?php echo display('product_vat').' %' ?>"
                                    value="<?php echo $product->product_vat?>" />
                            </div>
                        </div>
                 
                    

                    <?php if($supplier_pr){?>
                   
                        <div class="form-group row">
                            <label for="image" class="col-sm-2 col-form-label"> </label>
                            <div class="col-sm-4">
                                <img src="<?php echo base_url().$product->image?>" alt="" width="100" height="80">

                            </div>
                        </div>
                 
                    <?php }?>

                 
                    <?php 
                                 $i=0;

                    foreach ($taxfield as $taxss) {?>

                  
                    <div class="col-sm-6" <?php if($vattaxinfo->dynamic_tax != 1){ echo 'hidden';}?>>
                        <div class="form-group row">
                            <label for="tax" class="col-sm-4 col-form-label"><?php echo $taxss['tax_name']; ?> <i
                                    class="text-danger"></i></label>
                            <div class="col-sm-7">
                                <input type="text" name="tax<?php echo $i;?>" class="form-control" value="<?php  $taxv = 'tax'.$i;
                              echo (!empty($supplier_pr)?($product->$taxv*100): number_format($taxss['default_value'], 2, '.', ','));
                              ?>">
                            </div>
                            <div class="col-sm-1"> <i class="text-success">%</i></div>
                        </div>
                    </div>


                    <?php $i++;} ?>
             

				     <!-- Submit Button -->
                <div class="form-group row">
                    <div class="col-sm-12 text-right">
                        <input type="submit" id="add-product" class="btn btn-primary btn-large" name="add-product" value="<?php echo display('save') ?>" tabindex="15">
                    </div>
                </div>

				
            </div>
            <?php echo form_close() ?>
        </div>
        <input type="hidden" id="supplier_list"
            value='<?php if ($supplier) { ?><?php foreach($supplier as $suppliers){?><option value="<?php echo $suppliers['supplier_id']?>"><?php echo $suppliers['supplier_name']?></option><?php }}?>'
            name="">
    </div>
</div>

<script>

//Supplier filter irfan

"use strict";

function get_suppliers_by_company() {
    // Fetch company ID and base URL
    var company_id = $('#company_id').val();
    var base_url = $('#base_url').val(); // Assuming #base_url is a hidden input field
    var csrf_test_name = $('[name="csrf_test_name"]').val(); // CSRF token

    // Check if company ID is valid
    if (!company_id) {
        alert('Please select a company!');
        return false;
    }

    // AJAX request to fetch suppliers
    $.ajax({
        type: 'POST',
        url: base_url + "product/product/get_suppliers_by_company", // Constructed URL
        data: {
            company_id: company_id,
            csrf_test_name: csrf_test_name // CSRF token for security
        },
        dataType: 'json', // Expect JSON response
        success: function(data) {
            // Debug response
           // console.log('Suppliers Response:', data);

            // Clear and populate supplier dropdown
            $('#supplier_id').empty(); // Clear existing options
            $('#supplier_id').append('<option value=""><?php echo display("select_one"); ?></option>');

            if (data.length > 0) {
                // Populate suppliers dynamically
                $.each(data, function(index, supplier) {
                    $('#supplier_id').append('<option value="' + supplier.supplier_id + '">' + supplier.supplier_name + '</option>');
                });
            } else {
                alert('No suppliers found for the selected company.');
            }
        },
        error: function(xhr, status, error) {
            // Handle AJAX errors
            console.error('AJAX Error:', error);
            console.error('Response Text:', xhr.responseText);
            alert('Error fetching suppliers. Please try again.');
        }
    });
}

// Event listener for company dropdown change
$(document).ready(function() {
    $('#company_id').on('change', function() {
        get_suppliers_by_company(); // Call the function
    });
});

//Supplier filter irfan

</script>



<script>
"use strict";

function calculateUnitPrices() {
    var sellPrice = parseFloat(document.getElementById('sell_price').value) || 0;
    var costPrice = parseFloat(document.getElementById('cost_price').value) || 0;
    var boxSize = parseFloat(document.getElementById('box_size').value) || 1; // Default box size is 1

    // Calculate unit prices
    var unitSellPrice = sellPrice / boxSize;
    var unitCostPrice = costPrice / boxSize;

    // Update the read-only fields
    document.getElementById('unit_sell_price').value = unitSellPrice.toFixed(2);
    document.getElementById('unit_cost_price').value = unitCostPrice.toFixed(2);
}

// Event listeners for real-time updates
document.getElementById('sell_price').addEventListener('input', calculateUnitPrices);
document.getElementById('cost_price').addEventListener('input', calculateUnitPrices);
document.getElementById('box_size').addEventListener('input', calculateUnitPrices);

// Initial calculation on page load (optional)
document.addEventListener('DOMContentLoaded', function() {
    calculateUnitPrices();
});
</script>
