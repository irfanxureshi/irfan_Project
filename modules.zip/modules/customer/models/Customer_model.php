<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 

class Customer_model extends CI_Model {

     
public function create($data = array())
{
    // Insert into customer_information
    $add_customer = $this->db->insert('customer_information', $data);
    $customer_id = $this->db->insert_id();

    // Generate HeadCode
    $coa = $this->headcode();
    if (!$coa) {
        log_message('error', 'Failed to generate HeadCode. Limit might be reached.');
        return false;
    }
    $headcode = $coa + 1;

// Check Customer Type
    if ($data['customer_type'] === 'Business') {
        // Generate HeadCode for acc_coa
    // Prepare data for acc_coa
    $customer_coa = [
        'HeadCode'         => $headcode,
        'HeadName'         => $customer_id . '-' . $data['customer_name'],
        'PHeadName'        => 'Customers',
        'HeadLevel'        => '4',
        'IsActive'         => '1',
        'IsTransaction'    => '1',
        'IsGL'             => '0',
        'HeadType'         => 'A',
        'IsBudget'         => '0',
        'IsDepreciation'   => '0',
        'DepreciationRate' => '0',
        'customer_id'      => $customer_id,
        'CreateBy'         => $this->session->userdata('id'),
        'CreateDate'       => date('Y-m-d H:i:s'),
    ];

    $this->db->insert('acc_coa', $customer_coa);
    if ($this->db->affected_rows() <= 0) {
        log_message('error', 'Failed to insert customer into acc_coa.');
        return false;
    }}

    // Insert into acc_subcode
    $sub_acc = [
        'subTypeId'   => 3,
        'name'        => $data['customer_name'],
        'referenceNo' => $customer_id,
        'status'      => 1,
        'created_date'=> date("Y-m-d"),
    ];
           $this->db->insert('acc_subcode', $sub_acc);
           $acc_subcode_id = $this->db->insert_id();
   
   

   // Handle previous_balance
if (!empty($this->input->post('previous_balance'))) {
    $acc_transaction_data = [
        'VNo'         => 'OBTCUS-' . $customer_id,
        'Vtype'       => 'Opening Balance',
        'VDate'       => date('Y-m-d'),
        'COAID'       => $headcode,
        'Narration'   => 'Opening Balance for Customer: ' . $data['customer_name'],
        'Debit'       => $this->input->post('previous_balance', true),
        'Credit'      => 0,
        'IsPosted'    => 1,
        'CreateBy'    => $this->session->userdata('id'),
        'CreateDate'  => date('Y-m-d H:i:s'),
        'IsAppove'    => 1,
        'subType'     => 3,
        'subCode'     => $acc_subcode_id, // $ شامل کیا گیا
        'company_id'  => 1,
    ];

    $acc_transaction_dataa = [
        'VNo'         => 'OBTCUS-' . $customer_id,
        'Vtype'       => 'Opening Balance',
        'VDate'       => date('Y-m-d'),
        'COAID'       => 113100000001,
        'Narration'   => 'Opening Balance for Customer: ' . $data['customer_name'],
        'Debit'       => 0,
        'Credit'      => $this->input->post('previous_balance', true),
        'IsPosted'    => 1,
        'CreateBy'    => $this->session->userdata('id'),
        'CreateDate'  => date('Y-m-d H:i:s'),
        'IsAppove'    => 1,
        'subType'     => 3,
        'subCode'     => $acc_subcode_id, // $ شامل کیا گیا
        'company_id'  => 1,
    ];
        $this->db->insert('acc_transaction', $acc_transaction_data);
		$this->db->insert('acc_transaction', $acc_transaction_dataa);
        if ($this->db->affected_rows() <= 0) {
            log_message('error', 'Failed to insert customer opening balance into acc_transaction.');
            return false;
        }
    }

    return $add_customer;
}

	 
	 
   //public function headcode(){
       // $query=$this->db->query("SELECT MAX(HeadCode) as HeadCode FROM acc_coa WHERE HeadLevel='4' And HeadCode LIKE '113100%'");
       // return $query->row();

   // }
   
 public function headcode()
{
    $query = $this->db->query("SELECT MAX(HeadCode) as HeadCode FROM acc_coa WHERE HeadLevel = '4' AND HeadCode LIKE '113100%'");
    $result = $query->row();

    // اگر کوئی موجودہ HeadCode نہیں ہے، تو ڈیفالٹ ویلیو استعمال کریں
    if (empty($result->HeadCode)) {
        return 113100000001; // Default starting value
    }

    // اگر HeadCode حد تک پہنچ گیا ہو
    if ($result->HeadCode >= 9223372036854775807) { // BIGINT UNSIGNED max limit
        log_message('error', 'HeadCode limit reached. Cannot generate a new HeadCode.');
        return false;
    }

    return $result->HeadCode;
}





	public function customer_dropdown()
	{
		$data =  $this->db->select("*")
			->from('customer_information')
			->order_by('customer_name', 'asc')
			->get()
			->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->customer_id] = $value->customer_name;
      return $list;
    } else {
      return false; 
    }
	}

  //credit customer dropdown
    public function bdtask_credit_customer_dropdown()
  {
    $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance > 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->customer_id] = $value->customer_name;
      return $list;
    } else {
      return false; 
    }
  }


  // paid customer dropdown
   public function bdtask_paid_customer_dropdown()
  {
    $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance <= 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->customer_id] = $value->customer_name;
      return $list;
    } else {
      return false; 
    }
  }

	public function customer_list($offset=null, $limit=null)
    {
  

        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('customer_information a')
			->join('acc_coa b','a.customer_id = b.customer_id','left')
			->group_by('a.customer_id')
			->order_by('a.customer_name', 'asc')
			->limit($offset, $limit)
			->get()
			->result();

         
    }



       
public function getCustomerList($postData = null)
{
    $response = array();
    $customer_id = $this->input->post('customer_id');
    $custom_data = $this->input->post('customfiled');

    $cus_data = [];
    if (!empty($custom_data)) {
        foreach ($custom_data as $cusd) {
            $cus_data[] = $cusd;
        }
    }

    ## Read value
    $draw = $postData['draw'];
    $start = $postData['start'];
    $rowperpage = $postData['length']; // Rows display per page
    $columnIndex = $postData['order'][0]['column']; // Column index
    $columnName = $postData['columns'][$columnIndex]['data']; // Column name
    $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
    $searchValue = $postData['search']['value']; // Search value

    ## Search Query
    $searchQuery = "";
    if (!empty($searchValue)) {
        $searchQuery = " (
            c.customer_name LIKE '%" . $searchValue . "%' 
            OR c.customer_mobile LIKE '%" . $searchValue . "%' 
            OR c.customer_email LIKE '%" . $searchValue . "%'
            OR c.phone LIKE '%" . $searchValue . "%' 
            OR c.customer_address LIKE '%" . $searchValue . "%' 
            OR c.country LIKE '%" . $searchValue . "%' 
            OR c.state LIKE '%" . $searchValue . "%' 
            OR c.zip LIKE '%" . $searchValue . "%' 
            OR c.city LIKE '%" . $searchValue . "%'
        )";
    }

    ## Total number of records without filtering
    $this->db->select('COUNT(DISTINCT c.customer_id) AS allcount');
    $this->db->from('customer_information c');
    $this->db->join('acc_coa coa', 'coa.customer_id = c.customer_id', 'left');
    $this->db->join('acc_transaction at', 'at.COAID = coa.HeadCode', 'left');
    if (!empty($customer_id)) {
        $this->db->where('c.customer_id', $customer_id);
    }
    if (!empty($cus_data)) {
        $this->db->where_in('c.customer_id', $cus_data);
    }
    $totalRecords = $this->db->count_all_results();

    ## Total number of records with filtering
    $this->db->select('COUNT(DISTINCT c.customer_id) AS allcount');
    $this->db->from('customer_information c');
    $this->db->join('acc_coa coa', 'coa.customer_id = c.customer_id', 'left');
    $this->db->join('acc_transaction at', 'at.COAID = coa.HeadCode', 'left');
    if (!empty($customer_id)) {
        $this->db->where('c.customer_id', $customer_id);
    }
    if (!empty($cus_data)) {
        $this->db->where_in('c.customer_id', $cus_data);
    }
    if (!empty($searchQuery)) {
        $this->db->where($searchQuery);
    }
    $totalRecordwithFilter = $this->db->count_all_results();

    ## Fetch records
   $this->db->select("
    c.customer_id,
    c.customer_name,
    c.customer_address,
    c.city,
    c.state,
    c.zip,
    c.country,
    c.customer_mobile,
    c.customer_email,
    c.phone,
    coa.HeadCode AS account_code,
    coa.HeadName AS account_name,
    SUM(CASE WHEN at.Debit > 0 THEN at.Debit ELSE 0 END) AS total_debit,
    SUM(CASE WHEN at.Credit > 0 THEN at.Credit ELSE 0 END) AS total_credit,
    (SUM(CASE WHEN at.Debit > 0 THEN at.Debit ELSE 0 END) - 
     SUM(CASE WHEN at.Credit > 0 THEN at.Credit ELSE 0 END)) AS balance,
    inv_data.TotalPaidAmount,
    inv_data.TotalDueAmount,
    invoice_data.TotalInvoices
");
$this->db->from('customer_information c');
$this->db->join('acc_coa coa', 'coa.customer_id = c.customer_id', 'left');
$this->db->join('acc_transaction at', 'at.COAID = coa.HeadCode', 'left');
$this->db->join("(SELECT customer_id, 
                 SUM(paid_amount) AS TotalPaidAmount, 
                 SUM(due_amount) AS TotalDueAmount 
             FROM invoice 
             GROUP BY customer_id
             ) AS inv_data", 
             'inv_data.customer_id = c.customer_id', 
             'left');
$this->db->join("(SELECT 
                 customer_id, 
                 COUNT(DISTINCT invoice_id) AS TotalInvoices
             FROM invoice
             GROUP BY customer_id
             ) AS invoice_data",
             'invoice_data.customer_id = c.customer_id',
             'left');

// Apply filters if needed
    if (!empty($searchQuery)) {
        $this->db->where($searchQuery);
    }

    // Limit and offset for pagination
    $this->db->limit($rowperpage, $start);
    $this->db->group_by('c.customer_id'); // Group only by customer_id
    $this->db->order_by($columnName, $columnSortOrder);

    $records = $this->db->get()->result();

    ## Prepare Response Data
    $data = array();
    $sl = 1 + $start;


   

    foreach ($records as $record) {
        $button = '';
        $base_url = base_url();

        if ($this->permission1->method('manage_customer', 'update')->access()) {
            $button .= ' 
                <a href="' . $base_url . 'edit_customer/' . $record->customer_id . '" 
                   class="btn btn-info btn-xs m-b-5 custom_btn" 
                   data-toggle="tooltip" data-placement="left" title="Update">
                   <i class="pe-7s-note" aria-hidden="true"></i>
                </a>';
        }
        if ($this->permission1->method('manage_customer', 'delete')->access()) {
            $button .= ' 
                <a onclick="customerdelete(' . $record->customer_id . ')" 
                   href="javascript:void(0)" 
                   class="btn btn-danger btn-xs m-b-5 custom_btn" 
                   data-toggle="tooltip" data-placement="right" title="Delete">
                   <i class="pe-7s-trash" aria-hidden="true"></i>
                </a>';
        }

        $data[] = array(
            'sl' => $sl,
            'customer_name' => $record->customer_name,
            'address' => $record->customer_address,
            'mobile' => $record->customer_mobile,
            'email' => $record->customer_email,
            'city' => $record->city,
            'state' => $record->state,
            'zip' => $record->zip,
            'country' => $record->country,
        
			'invoice_no' => $record->TotalInvoices, // Include Total Invoices
			'paid_ammount' => number_format($record->TotalPaidAmount, 2),
            'due_amount' => number_format($record->TotalDueAmount, 2),
            'debit_plus' => number_format($record->total_debit, 2),
            'credit_minus' => number_format($record->total_credit, 2),
            'balance' => number_format($record->balance, 2),
            'button' => $button
        );
        $sl++;
    }

    ## Response
    $response = array(
        "draw" => intval($draw),
        "iTotalRecords" => $totalRecords,
        "iTotalDisplayRecords" => $totalRecordwithFilter,
        "aaData" => $data
    );

    return $response;
}



          public function getCreditCustomerList($postData=null){

         $response = array();
         $customer_id =  $this->input->post('customer_id');
         $custom_data = $this->input->post('customfiled');
         if(!empty($custom_data)){
         $cus_data = [''];
         foreach ($custom_data as $cusd) {
           $cus_data[] = $cusd;
         }
       }
    
         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search 
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (a.customer_name like '%".$searchValue."%' or a.customer_mobile like '%".$searchValue."%' or a.customer_email like '%".$searchValue."%'or a.phone like '%".$searchValue."%' or a.customer_address like '%".$searchValue."%' or a.country like '%".$searchValue."%' or a.state like '%".$searchValue."%' or a.zip like '%".$searchValue."%' or a.city like '%".$searchValue."%') ";
         }

         ## Total number of records without filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
         if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
          if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance > 0'); 
         $this->db->group_by('a.customer_id');
         $totalRecords =$this->db->get()->num_rows();

         ## Total number of record with filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
            $this->db->where($searchQuery);
           $this->db->having('balance > 0');
           $this->db->group_by('a.customer_id');
         $totalRecordwithFilter = $this->db->get()->num_rows();

         ## Fetch records
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         $this->db->group_by('a.customer_id');
          if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance > 0');
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $records = $this->db->get()->result();
         $data = array();
         $sl =1;
  
         foreach($records as $record ){
          $button = '';
          $base_url = base_url();
 
          if($this->permission1->method('credit_customer','update')->access()){
            $button .=' <a href="'.$base_url.'edit_customer/'.$record->customer_id.'" class="btn btn-info btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="left" title="Update"><i class="pe-7s-note" aria-hidden="true"></i></a>';
          }
          if($this->permission1->method('credit_customer','dalete')->access()){
            $button .=' <a onclick="customerdelete('.$record->customer_id.')" href="javascript:void(0)"  class="btn btn-danger btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="right" title="Delete "><i class="pe-7s-trash" aria-hidden="true"></i></a>';
          }


        
               
            $data[] = array( 
                'sl'               =>$sl,
                'customer_name'    =>$record->customer_name,
                'address'          =>$record->customer_address,
                'address2'         =>$record->address2,
                'mobile'           =>$record->customer_mobile,
                'phone'            =>$record->phone,
                'email'            =>$record->customer_email,
                'email_address'    =>$record->email_address,
                'contact'          =>$record->contact,
                'fax'              =>$record->fax,
                'city'             =>$record->city,
                'state'            =>$record->state,
                'zip'              =>$record->zip,
                'country'          =>$record->country,
                'balance'          =>(!empty($record->balance)?$record->balance:0),
                'button'           =>$button,
                
            ); 
            $sl++;
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
         );

         return $response; 
    }

    //paid customer list
     public function bdtask_getPaidCustomerList($postData=null){

         $response = array();
         $customer_id =  $this->input->post('customer_id');
         $custom_data = $this->input->post('customfiled');
         if(!empty($custom_data)){
         $cus_data = [''];
         foreach ($custom_data as $cusd) {
           $cus_data[] = $cusd;
         }
       }
    
         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search 
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (a.customer_name like '%".$searchValue."%' or a.customer_mobile like '%".$searchValue."%' or a.customer_email like '%".$searchValue."%'or a.phone like '%".$searchValue."%' or a.customer_address like '%".$searchValue."%' or a.country like '%".$searchValue."%' or a.state like '%".$searchValue."%' or a.zip like '%".$searchValue."%' or a.city like '%".$searchValue."%') ";
         }

         ## Total number of records without filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
         if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
          if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance <= 0'); 
         $this->db->group_by('a.customer_id');
         $totalRecords =$this->db->get()->num_rows();

         ## Total number of record with filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
            $this->db->where($searchQuery);
           $this->db->having('balance <= 0');
           $this->db->group_by('a.customer_id');
         $totalRecordwithFilter = $this->db->get()->num_rows();

         ## Fetch records
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         $this->db->group_by('a.customer_id');
          if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance <= 0');
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $this->db->group_by('a.customer_id');
         $records = $this->db->get()->result();
         $data = array();
         $sl =1;
  
         foreach($records as $record ){
          $button = '';
          $base_url = base_url();
 
          if($this->permission1->method('paid_customer','update')->access()){
            $button .=' <a href="'.$base_url.'edit_customer/'.$record->customer_id.'" class="btn btn-info btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="left" title="Update"><i class="pe-7s-note" aria-hidden="true"></i></a>';
          }
          if($this->permission1->method('paid_customer','delete')->access()){
            $button .=' <a onclick="customerdelete('.$record->customer_id.')" href="javascript:void(0)"  class="btn btn-danger btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="right" title="Delete "><i class="pe-7s-trash" aria-hidden="true"></i></a>';
          }


        
               
            $data[] = array( 
                'sl'               =>$sl,
                'customer_name'    =>$record->customer_name,
                'address'          =>$record->customer_address,
                'address2'         =>$record->address2,
                'mobile'           =>$record->customer_mobile,
                'phone'            =>$record->phone,
                'email'            =>$record->customer_email,
                'email_address'    =>$record->email_address,
                'contact'          =>$record->contact,
                'fax'              =>$record->fax,
                'city'             =>$record->city,
                'state'            =>$record->state,
                'zip'              =>$record->zip,
                'country'          =>$record->country,
                'balance'          =>(!empty($record->balance)?$record->balance:0),
                'button'           =>$button,
                
            ); 
            $sl++;
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
         );

         return $response; 
    }

    public function individual_info($id){
      return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->where('a.customer_id',$id)
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();
    }

    public function credit_customer($offset=null, $limit=null)
    {
  

        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('customer_information a')
			->join('acc_coa b','a.customer_id = b.customer_id','left')
			->having('balance > 0') 
			->group_by('a.customer_id')
			->order_by('a.customer_name', 'asc')
			->limit($offset, $limit)
			->get()
			->result();

         
    }


     public function count_credit_customer()
    {
        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('customer_information a')
			->join('acc_coa b','a.customer_id = b.customer_id','left')
			->having('balance > 0') 
			->group_by('a.customer_id')
			->order_by('a.customer_name', 'asc')
			->get()
			->num_rows();

         
    }

	public function singledata($id = null)
	{
		return $this->db->select('*')
			->from('customer_information')
			->where('customer_id', $id)
			->get()
			->row();
	}

  public function allcustomer()
  {
    return $this->db->select('*')
      ->from('customer_information')
      ->get()
      ->result();
  }

  public function bdtask_all_credit_customer(){

   return $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance > 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();
  }

    public function bdtask_all_paid_customer(){

   return $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance <= 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();
  }

	public function update($data = array())
	{
		$updatecustomer =  $this->db->where('customer_id', $data["customer_id"])
			->update("customer_information", $data);

		$customer_id = $data["customer_id"];
        $old_headnam = $customer_id.'-'.$this->input->post("old_name");
        $c_acc=$customer_id.'-'.$data["customer_name"];
         $customer_coa = [
             'HeadName'         => $c_acc
        ];

        $sub_acc = [
          'name'        => $data['customer_name'],
        ];

        $this->db->where('referenceNo', $customer_id)
                 ->where('subTypeId', 3)
                 ->update('acc_subcode',$sub_acc);
     
      return true;
	}

	public function delete($id = null)
	{
    $this->db->where('referenceNo', $id)
                 ->where('subTypeId', 3)
                 ->delete('acc_subcode');

		return $this->db->where('customer_id', $id)
			->delete("customer_information");
	}


	  


    public function previous_balance_add($balance, $customer_id) {
    $cusifo = $this->db->select('*')->from('customer_information')->where('customer_id',$customer_id)->get()->row();
    $headn = $customer_id.'-'.$cusifo->customer_name;
    $coainfo = $this->db->select('*')->from('acc_coa')->where('HeadName',$headn)->get()->row();
    $customer_headcode = $coainfo->HeadCode;
        $transaction_id = $this->generator(10);
       

// Customer debit for previous balance
      $cosdr = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'PR Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  $customer_headcode,
      'Narration'      =>  'Customer debit For '.$cusifo->customer_name,
      'Debit'          =>  $balance,
      'Credit'         =>  0,
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    );
       $inventory = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'PR Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  1141,
      'Narration'      =>  'Inventory credit For Old sale For'.$cusifo->customer_name,
      'Debit'          =>  0,
      'Credit'         =>  $balance,//purchase price asbe
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    ); 

       
        if(!empty($balance)){
           $this->db->insert('acc_transaction', $cosdr); 
           $this->db->insert('acc_transaction', $inventory); 
        }
    }



public function generator($lenth)
    {
        $number=array("A","B","C","D","E","F","G","H","I","J","K","L","N","M","O","P","Q","R","S","U","V","T","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0");
    
        for($i=0; $i<$lenth; $i++)
        {
            $rand_value=rand(0,34);
            $rand_number=$number["$rand_value"];
        
            if(empty($con))
            { 
            $con=$rand_number;
            }
            else
            {
            $con="$con"."$rand_number";}
        }
        return $con;
    }


          public function customer_ledgerdata($per_page, $page) {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where('b.PHeadName','Customer Receivable');
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        
        public function count_customer_ledger() {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where('b.PHeadName','Customer Receivable');
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }
  

      public function customer_list_ledger() {
        $this->db->select('*');
        $this->db->from('customer_information');
        $this->db->order_by('customer_name', 'asc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        public function customer_personal_data($customer_id) {
        $this->db->select('*');
        $this->db->from('customer_information');
        $this->db->where('customer_id', $customer_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }
	

    
	
	
    public function customerledger_searchdata($customer_id, $start, $end) {
    $this->db->select('a.*,b.HeadName');
    $this->db->from('acc_transaction a');
    $this->db->join('acc_coa b', 'a.COAID = b.HeadCode');
    $this->db->join('customer_information c', 'b.customer_id = c.customer_id', 'left');
    $this->db->join('invoice i', 'i.invoice_id = a.referenceNo AND i.customer_id = c.customer_id', 'left');

    $this->db->where(array('b.customer_id' => $customer_id, 'a.VDate >=' => $start, 'a.VDate <=' => $end));
    $this->db->where('a.IsAppove', 1);
    $this->db->order_by('a.VDate', 'desc');
    
    $query = $this->db->get();

    // Log the query for debugging
    log_message('debug', 'Customer Ledger Query: ' . $this->db->last_query());

    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return false;
}


        public function customer_list_advance(){
        $this->db->select('*');
        $this->db->from('customer_information');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        public function advance_details($transaction_id,$customer_id){

        $headcode = $this->db->select('HeadCode')->from('acc_coa')->where('customer_id',$customer_id)->get()->row();
        return $data  = $this->db->select('*')
                        ->from('acc_transaction')
                        ->where('VNo',$transaction_id)
                        ->where('COAID',$headcode->HeadCode)
                        ->get()
                        ->result_array();

    }
	
	
	
	
		
	//irfan get all company data
   // Fetch all company data from the database
   
   
    public function getAllCompanies() {
        $query = $this->db->get('company_information'); // Replace with your table name
        return $query->result(); // Return result as an array of objects
    }
	
	public function getAllCompaniesarray() {
        $query = $this->db->get('company_information'); // Replace with your table name
        return $query->result_array(); // Return result as an array of objects
    }
	/*public function getCompanyById($company_id) {
    $this->db->where('company_id', $company_id);
    $query = $this->db->get('company_information'); // Table name here
    return $query->row_array(); // Return a single row as an associative array
}*/

//irfan end
	
	
	
	
	

}

