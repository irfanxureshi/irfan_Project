 <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo $title ?> </h4>
                        </div>
                    </div>
                   
                    <div class="panel-body">
    
<div class="table-responsive">
                <table class="table table-bordered" id="CustomerList"  width="100%">
                    <thead>
 
                        <tr>
                            <th><?php echo display('sl') ?></th>
                            <th><?php echo display('customer_name') ?></th>
                            <th><?php echo display('address1'); ?></th>
                            <th><?php echo display('mobile_no') ?></th>
                            <th><?php echo display('email'); ?></th>
                            <th><?php echo display('vat_no'); ?></th>
                            <th><?php echo display('cr_no') ?></th>
                            <th><?php echo display('zip'); ?></th>
                            <th><?php echo display('country'); ?></th> 
							<th><?php echo display('total'); ?> <?php echo display('invoice_no'); ?></th>
							 <th><?php echo display('total'); ?> Invoice <?php echo display('paid_ammount'); ?></th>
                            <th><?php echo display('total'); ?> Invoice Receivable amount</th>
                            <th><?php echo display('total'); ?> Personal Loan <?php echo display('debit_plus'); ?></th>
                            <th><?php echo display('total'); ?> Personal Loan <?php echo display('credit_minus'); ?></th>
                            <th><?php echo display('total'); ?> Advance <?php echo display('balance') ?></th>
                            <th width="50px;"><?php echo display('action') ?> 
							
                        
                            </th>
                        </tr>
                    </thead>
                    <tbody id="customer_tablebody">
                       
                    </tbody>
                    <tfoot>
                                            <tr>
                <th colspan="14" class="text-right"><?php echo display('total') ?>:</th>
                <th id="stockqty"></th>
                   <th></th>
            </tr>
                                            
                                        </tfoot>
                  </table>  
              </div>
                  
            </div>
         

        </div>
    </div>
</div><style>
    /* Table responsiveness for mobile devices */
    @media (max-width: 768px) {
        td[data-label]::before {
            content: attr(data-label); /* Show column name in mobile rows */
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        td[data-label] {
            display: block; /* Display each cell as a block on mobile */
            text-align: left;
        }

        th, td {
            white-space: nowrap; /* Prevent wrapping of content */
        }
        
        

        .table thead {
            display: none; /* Hide table headers on mobile */
        }
    }
</style>
