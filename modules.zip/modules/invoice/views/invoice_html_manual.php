<link
    href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap"
    rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400;1,700&display=swap"
    rel="stylesheet">

<style>
*,
::after,
::before {
    box-sizing: border-box;
}

body {
    padding: 0;
    font-family: Lato, "Helvetica Neue", Arial, Helvetica, sans-serif;
}
</style>

<style>
/* General Reset */
*,
::after,
::before {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Lato', "Helvetica Neue", Arial, Helvetica, sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f5f5f5;
}

/* Invoice Layout */
.invoice-wrap {
    width: 210mm; /* A4 width */
    min-height: 297mm; /* A4 height */
    margin: auto;
    padding: 20mm;
    background: #fff;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.header-section {
    text-align: center;
    margin-bottom: 20px;
}

.header-section img {
    max-width: 120px;
    margin-bottom: 10px;
}

.header-section h1 {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 5px;
}

.header-section p {
    font-size: 14px;
    color: #666;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    font-size: 12px;
}

.table th,
.table td {
    border: 1px solid #ccc;
    text-align: left;
    padding: 10px;
}

.table th {
    background: #f7f7f7;
    font-weight: bold;
}

.summary-table {
    margin-top: 20px;
}

.summary-table th {
    text-align: right;
    font-size: 14px;
}

.summary-table td {
    text-align: right;
    font-weight: bold;
}

.text-center {
    text-align: center;
}

.text-right {
    text-align: right;
}

.text-left {
    text-align: left;
}

.footer-section {
    margin-top: 30px;
    font-size: 12px;
    text-align: center;
    color: #666;
}

@media print {
    body {
        margin: 0;
        background: none;
    }

    .invoice-wrap {
        box-shadow: none;
        border: none;
        width: auto;
        height: auto;
    }

    .no-print {
        display: none;
    }
}
</style>
<div class="invoice-wrap">
    <!-- Header Section -->
    <div class="header-section">
        <?php
        // چیک کریں کہ کمپنیاں موجود ہیں اور لوپ کریں
        if (!empty($companiesarray) && is_array($companiesarray)): 
            foreach ($companiesarray as $company):
                // چیک کریں کہ انوائس کمپنی آئی ڈی کمپنی کی آئی ڈی سے میچ کرتی ہے
                if (isset($invoice_all_data[0]['company_id']) && $company['company_id'] == $invoice_all_data[0]['company_id']): ?>
                    <!-- کمپنی لوگو -->
                    <img src="<?php echo base_url(!empty($company['logo']) ? $company['logo'] : 'assets/img/default_logo.png'); ?>" 
                         alt="Company Logo" style="max-width: 120px; margin-bottom: 10px;">
                    
                    <!-- کمپنی کا نام اور ایڈریس -->
                    <h2><?php echo html_escape($company['company_name']); ?></h2>
                    <p><?php echo html_escape($company['address']); ?></p>
                    
                    <!-- رابطے کی تفصیلات -->
                    <p>
                        <strong><?php echo display('phone'); ?>:</strong> <?php echo html_escape($company['mobile']); ?><br>
                        <strong><?php echo display('email'); ?>:</strong> <?php echo html_escape($company['email']); ?><br>
                        <strong><?php echo display('website'); ?>:</strong> <?php echo html_escape($company['website']); ?>
                    </p>
                    
                    <!-- VAT اور CR نمبر -->
                    <?php if (!empty($company['vat_no'])): ?>
                        <p><strong><?php echo display('vat_no'); ?>:</strong> <?php echo html_escape($company['vat_no']); ?></p>
                    <?php endif; ?>
                    
                    <?php if (!empty($company['cr_no'])): ?>
                        <p><strong><?php echo display('cr_no'); ?>:</strong> <?php echo html_escape($company['cr_no']); ?></p>
                    <?php endif; ?>
                <?php 
                break; // صرف ایک کمپنی دکھانے کے بعد لوپ ختم کریں
                endif; 
            endforeach; 
        else: ?>
            <p>No company information available.</p>
        <?php endif; ?>
    </div>

    <!-- Invoice Details -->
    <table class="table">
        <tbody>
            <tr>
                <th><?php echo display('date'); ?>:</th>
                <td><?php echo $final_date; ?></td>
            </tr>
            <tr>
                <th><?php echo display('invoice_no'); ?>:</th>
                <td><?php echo $invoice_no; ?></td>
            </tr>
            <tr>
                <th><?php echo display('customer'); ?>:</th>
                <td><?php echo $customer_name; ?></td>
            </tr>
            <?php if (!empty($customer_mobile)) { ?>
            <tr>
                <th><?php echo display('phone'); ?>:</th>
                <td><?php echo $customer_mobile; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Items Table -->
    <table class="table">
        <thead>
            <tr>
                <th><?php echo display('item'); ?></th>
                <th><?php echo display('qty2'); ?></th>
                <th><?php echo display('batch'); ?></th>
                <th><?php echo display('price'); ?></th>
                <th><?php echo display('disc'); ?></th>
                <?php if (!empty($invoice_all_data[0]['vat_amnt'])) { ?>
                <th><?php echo display('vat'); ?></th>
                <?php } ?>
                <th><?php echo display('tot_price'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $itemrow = 0;
            foreach ($invoice_all_data as $invoice_data) { ?>
            <tr>
                <td><?php echo html_escape($invoice_data['product_name']); ?></td>
                <td><?php echo html_escape($invoice_data['quantity']); ?></td>
                <td><?php echo html_escape($invoice_data['batch_id']); ?></td>
                <td><?php echo html_escape($invoice_data['rate']); ?></td>
                <td><?php echo html_escape($invoice_data['discount']); ?></td>
                <?php if (!empty($invoice_data['vat_amnt'])) { ?>
                <td><?php echo html_escape($invoice_data['vat_amnt']); ?></td>
                <?php } ?>
                <td><?php echo html_escape($invoice_data['total_price']); ?></td>
            </tr>
            <?php $itemrow += $invoice_data['rate'] * $invoice_data['quantity'];
            } ?>
        </tbody>
    </table>

    <!-- Summary Table -->
    <table class="table summary-table">
        <tbody>
            <tr>
                <th><?php echo display('tot_before_dis'); ?>:</th>
                <td><?php echo number_format($itemrow, 2, '.', ','); ?></td>
            </tr>
            <tr>
                <th><?php echo display('discounts'); ?>:</th>
                <td><?php echo $all_discount; ?></td>
            </tr>
            <tr>
                <th><?php echo display('grand_total'); ?>:</th>
                <td><?php echo $grand_total; ?></td>
            </tr>
        </tbody>
    </table>

    <!-- QR Code -->
    <?php if ($web_setting->is_qr == 1) { ?>
    <div class="text-center">
        <?php $text = base64_encode(display('invoice_no') . ': ' . $invoice_no . ' ' . display('customer_name') . ': ' . $customer_name); ?>
        <img src="http://chart.apis.google.com/chart?cht=qr&chs=200x200&chld=L|4&chl=<?php echo $text; ?>" alt="QR Code">
    </div>
    <?php } ?>

    <!-- Footer -->
    <div class="footer-section">
        <p><?php echo display('thank_you'); ?>!</p>
    </div>
</div>
