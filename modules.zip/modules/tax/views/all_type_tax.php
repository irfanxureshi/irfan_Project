<!DOCTYPE html>
<html>
<head>
    <title>Tax Report</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
        .green { color: green; }
        .red { color: red; }
    </style>
</head>
<body>
    <h1>Tax Report</h1>

    <?php echo form_open('all_type_tax', array('class' => 'form-inline', 'method' => 'get')) ?>
        <label>Company:</label>
        <input type="text" name="company_id" value="<?= $filters['company_id'] ?? '' ?>">
        <label>Date Range:</label>
        <input type="date" name="start_date" value="<?= $filters['start_date'] ?? '' ?>">
        <input type="date" name="end_date" value="<?= $filters['end_date'] ?? '' ?>">
        <button type="submit">Filter</button>
    <?php echo form_close() ?>

    <table>
        <thead>
            <tr>
                <th>Invoice ID</th>
                <th>Type</th>
                <th>Party Name</th>
                <th>Taxable Amount</th>
                <th>Tax Rate</th>
                <th>Tax Amount</th>
                <th>Invoice Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($report as $row): ?>
            <tr>
                <td><?= $row['invoice_id'] ?></td>
                <td><?= $row['transaction_type'] ?></td>
                <td><?= $row['party_name'] ?></td>
                <td><?= number_format($row['taxable_amount'], 2) ?></td>
                <td><?= $row['tax_rate'] ?>%</td>
                <td class="green"><?= number_format($row['tax_amount'], 2) ?></td>
                <td><?= $row['invoice_date'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
