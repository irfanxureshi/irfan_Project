

      

        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <span><?php echo display('tax_company'); ?> </span>
                            <span class="padding-lefttitle">
                                          <?php if($this->permission1->method('todays_sales_report','read')->access()){ ?>
                    <a href="<?php echo base_url('sales_report') ?>" class="btn btn-info m-b-5 m-r-2"><i class="ti-align-justify"> </i> <?php echo display('sales_report') ?> </a>
                <?php }?>
        <?php if($this->permission1->method('todays_purchase_report','read')->access()){ ?>
                    <a href="<?php echo base_url('purchase_report') ?>" class="btn btn-success m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('purchase_report') ?> </a>
                  <?php }?>
                  <?php if($this->permission1->method('product_sales_reports_date_wise','read')->access()){ ?>
                    <a href="<?php echo base_url('product_wise_sales_report') ?>" class="btn btn-primary m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('sales_report_product_wise') ?> </a>
                    <?php }?>
    <?php if($this->permission1->method('todays_sales_report','read')->access() && $this->permission1->method('todays_purchase_report','read')->access()){ ?>
                    <a href="<?php echo base_url('profit_report') ?>" class="btn btn-warning m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('profit_report') ?> </a>
                    <?php }?>
                            </span>
                        </div>
                    </div>
					
					
					  <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
					
                      <?php echo form_open('tax_report_company_wise', array('class' => 'form-inline', 'method' => 'get')) ?>
     <label for="company_id">Select Company:</label>
    <select name="company_id" id="company_id">
        <option value="">All Companies</option>
        <?php 
        // Load companies dynamically
        $companies = $this->db->get('company_information')->result_array();
        foreach ($companies as $company) {
            echo "<option value='{$company['company_id']}'>{$company['company_name']}</option>";
        }
        ?>
    </select>

    <label for="start_date">Start Date:</label>
    <input type="date" name="start_date" id="start_date" value="<?php echo isset($start_date) ? $start_date : ''; ?>" required>

    <label for="end_date">End Date:</label>
    <input type="date" name="end_date" id="end_date" value="<?php echo isset($end_date) ? $end_date : ''; ?>" required>

    <button type="submit">Generate Report</button>
   <?php echo form_close() ?>
						
                    </div>
                </div>
            </div>
        </div>
		
                    <div class="panel-body">
                        <div id="purchase_div">
                            <div class="paddin5ps">
							
							
									 <h1><?php echo display('tax_company'); ?></h1>
    <p>Period: <?php echo $start_date; ?> to <?php echo $end_date; ?></p>
    <?php if (!empty($company_id)) { ?>
        <p>Company: <?php echo $tax_data[0]['company_name']; ?></p>
    <?php } else { ?>
        <p>All Companies</p>
    <?php } ?>

    <div class="table-responsive paddin5ps">
                                <table class="table table-bordered table-striped table-hover">
        <thead>
            <tr>
                <th>Invoice #</th>
                <th>Date</th>
                <th>Company</th>
                <th>Total Amount</th>
                <th>Fixed Tax</th>
                <th>Dynamic Tax</th>
                <th>Total Tax</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_fixed_tax = 0;
            $total_dynamic_tax = 0;
            $grand_total = 0;

            foreach ($tax_data as $tax) { 
                $total_fixed_tax += $tax['fixed_tax'];
               // $total_dynamic_tax += $tax['dynamic_tax'];
                $grand_total += $tax['total_amount'];
            ?>
            <tr>
                <td><?php echo $tax['invoice_id']; ?></td>
                <td><?php echo $tax['date']; ?></td>
                <td><?php echo $tax['company_name']; ?></td>
                <td><?php echo number_format($tax['total_amount'], 2); ?></td>
                <td><?php echo number_format($tax['fixed_tax'], 2); ?></td>
                <td><?php //echo number_format($tax['dynamic_tax'], 2); ?></td>
                <td><?php echo number_format($tax['fixed_tax'], 2); ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <h2>Summary</h2>
    <h3>Total Fixed Tax: <?php echo number_format($total_fixed_tax, 2); ?></h3>
     <h3>Total Dynamic Tax: <?php //echo number_format($total_dynamic_tax, 2); ?></h3>
    <h3>Grand Total: <?php echo number_format($grand_total, 2); ?></h3>									

                             
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>  </div>
