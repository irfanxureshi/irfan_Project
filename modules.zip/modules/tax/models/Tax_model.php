<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  

class Tax_model extends CI_Model {


    public function tax_setting_info(){
        $this->db->select('*');
        $this->db->from('tax_settings');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
 }


  public function taxsetup_create($data = array()){
     return $this->db->insert('payroll_tax_setup',$data);
    }

          public function viewTaxsetup()
    {
        return $this->db->select('*')   
            ->from('payroll_tax_setup')
            ->order_by('tax_setup_id', 'asc')
            ->get()
            ->result();
    }


 public function taxsetup_updateForm($id){
        $this->db->where('tax_setup_id',$id);
        $query = $this->db->get('payroll_tax_setup');
        return $query->result_array();
    }


     public function update_taxsetup($data = array())
    {
        return $this->db->where('tax_setup_id', $data["tax_setup_id"])
            ->update("payroll_tax_setup", $data);


    }

  public function taxsetup_delete($id = null){
        $this->db->where('tax_setup_id',$id)
            ->delete('payroll_tax_setup');

        if ($this->db->affected_rows()) {
            return true;
        } else {
            return false;
        }
    }


        //tax report query
    public function taxdata($from_date,$to_date){
        return $this->db->select('a.*,b.invoice')
                        ->from('tax_collection a')
                        ->join('invoice b','a.relation_id = b.invoice_id','left')
                        ->where('a.date >=', $from_date)
                        ->where('a.date <=', $to_date)
                        ->get()
                        ->result_array();
    }

       public function tax_customer(){
        return $this->db->select('*')
                        ->from('customer_information')
                        ->get()
                        ->result_array();
    }

      public function customer_taxdata($from_date,$to_date,$invoice_id){
        $this->db->select('a.*,b.invoice');
        $this->db->from('tax_collection a');
        $this->db->join('invoice b','a.relation_id = b.invoice_id','left');
        $this->db->where('a.date >=', $from_date);
        $this->db->where('a.date <=', $to_date);
        if (!empty($invoice_id)) {
            $this->db->where('b.invoice', $invoice_id);
            $this->db->or_where('a.relation_id', $invoice_id);
        }
        $query = $this->db->get();
        return $query->result_array();

    }
	
	
	
	public function get_tax_report($start_date = null, $end_date = null, $company_id = null) {
    $this->db->select('
        tax_collection.relation_id AS invoice_id,
        tax_collection.date,
        tax_collection.tax0 AS fixed_tax,
        invoice.total_vat_amnt,
        invoice.total_tax AS dynamic_tax,
        invoice.total_amount,
        company_information.company_name,
        tax_collection.company_id
    ');
    $this->db->from('tax_collection');
    $this->db->join('invoice', 'tax_collection.relation_id = invoice.invoice_id', 'left');
    $this->db->join('company_information', 'tax_collection.company_id = company_information.company_id', 'left');

    // تاریخوں کے لیے کنڈیشنز
    if (!empty($start_date)) {
        $this->db->where('tax_collection.date >=', $start_date);
    }
    if (!empty($end_date)) {
        $this->db->where('tax_collection.date <=', $end_date);
    }

    // کمپنی کے لیے فلٹر
    if (!empty($company_id)) {
        $this->db->where('tax_collection.company_id', $company_id);
    }

    $query = $this->db->get();
    return $query->result_array();
}

	



    
    // Fetch Tax Report Data
    public function get_tax_alltypereport($filters) {
        // Sales Tax
        $this->db->select("
            'Sales' AS transaction_type,
            i.invoice_id AS invoice_id,
            c.customer_name AS party_name,
            i.total_amount AS taxable_amount,
            id.vat_amnt_per AS tax_rate,
            id.vat_amnt AS tax_amount,
            i.date AS invoice_date
        ");
        $this->db->from('invoice i');
        $this->db->join('invoice_details id', 'i.id = id.invoice_id', 'left');
        $this->db->join('customer_information c', 'i.customer_id = c.customer_id', 'left');
        $this->db->where('i.company_id', $filters['company_id'] ?? null);

        $sales_query = $this->db->get_compiled_select();

        // Purchase Tax
        $this->db->select("
            'Purchase' AS transaction_type,
            pp.purchase_id AS invoice_id,
            s.supplier_name AS party_name,
            pp.grand_total_amount AS taxable_amount,
            ppd.vat_amnt_per AS tax_rate,
            ppd.vat_amnt AS tax_amount,
            pp.purchase_date AS invoice_date
        ");
        $this->db->from('product_purchase pp');
        $this->db->join('product_purchase_details ppd', 'pp.id = ppd.purchase_id', 'left');
        $this->db->join('supplier_information s', 'pp.supplier_id = s.supplier_id', 'left');
        $this->db->where('pp.company_id', $filters['company_id'] ?? null);

        $purchase_query = $this->db->get_compiled_select();

        // Service Tax
        $this->db->select("
            'Service' AS transaction_type,
            si.voucher_no AS invoice_id,
            c.customer_name AS party_name,
            si.total_amount AS taxable_amount,
            sid.vat AS tax_rate,
            sid.vat_amnt AS tax_amount,
            si.date AS invoice_date
        ");
        $this->db->from('service_invoice si');
        $this->db->join('service_invoice_details sid', 'si.id = sid.service_inv_id', 'left');
        $this->db->join('customer_information c', 'si.customer_id = c.customer_id', 'left');
        $this->db->where('si.company_id', $filters['company_id'] ?? null);

        $service_query = $this->db->get_compiled_select();

        // Combine Queries
        $query = $this->db->query("$sales_query UNION $purchase_query UNION $service_query");

        return $query->result_array();
    }



	
	
	
	
	
	
	
	
	
	
	

}

