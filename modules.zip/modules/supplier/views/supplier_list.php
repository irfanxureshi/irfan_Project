 <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo $title ?> </h4>
                        </div>
                    </div>
                   
                    <div class="panel-body">
                  <table class="table table-bordered" id="supplierList" width="100%">
                    <thead>
 
                        <tr>
                            <th><?php echo display('sl') ?></th>
                            <th><?php echo display('supplier_name') ?></th> 
							<th><?php echo display('company_names') ?></th>
                            <th><?php echo display('address1'); ?></th>
                            <th><?php echo display('mobile_no') ?></th>
                            <th><?php echo display('email'); ?></th>
                            <th><?php echo display('city'); ?></th>
                            <th><?php echo display('state'); ?></th>
                            <th><?php echo display('zip'); ?></th>
                            <th><?php echo display('country'); ?></th>
							<th><?php echo display('total'); ?> <?php echo display('Purchase_no'); ?></th>
							 <th><?php echo display('total'); ?> Purchase <?php echo display('paid_ammount'); ?></th>
                            <th><?php echo display('total'); ?> Purchase <?php echo display('due_amount') ?></th>
                            <th><?php echo display('total'); ?> Advance <?php echo display('debit_plus'); ?></th>
                            <th><?php echo display('total'); ?> Advance <?php echo display('credit_minus'); ?></th>
                            <th><?php echo display('balance') ?></th>
                            <th width="50px;"><?php echo display('action') ?> 
                            </th>
                        </tr>
                    </thead>
                    <tbody id="supplier_tablebody">
                       
                    </tbody>
                    <tfoot>
                                            <tr>
                <th colspan="15" class="text-right"><?php echo display('total') ?>:</th>
                <th id="stockqty"></th>
                   <th></th>
            </tr>
                                            
                                        </tfoot>
                  </table>  
                  
            </div>
         

        </div>
    </div>
</div>
    



                            
   

<script>
$(document).ready(function() {
    $('#supplierTable').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            url: '<?php echo base_url("Supplier/bdtask_ChecksupplierList"); ?>', // Updated controller name
            "type": "POST"
        },
        "columns": [
            { "data": "sl" },
            { "data": "supplier_name" },
            { "data": "address" },
            { "data": "mobile" },
            { "data": "email" },
            { "data": "city" },
            { "data": "state" },
			{ "data": "zip" },
            { "data": "country" },
            { "data": "balance" },
            { "data": "button" } // Action buttons
        ]
    });
});
</script>


    <!--<script>
    $(document).ready(function() {
        $.ajax({
            url: '<?php echo base_url("Supplier/bdtask_ChecksupplierList"); ?>', // Updated controller name
            type: 'POST',
            dataType: 'json',
            success: function(response) {
                var tbody = $('#supplier_tablebody');
                tbody.empty();

                $.each(response.aaData, function(index, record) {
                    var row = $('<tr>');
                    row.append($('<td>').text(record.sl)); // Serial number
                    row.append($('<td>').text(record.supplier_name)); // Supplier Name
                    row.append($('<td>').text(record.address)); // Address
                    row.append($('<td>').text(record.mobile)); // Mobile
                    row.append($('<td>').text(record.email)); // Email
                    row.append($('<td>').text(record.city)); // City
                    row.append($('<td>').text(record.state)); // State
                    row.append($('<td>').text(record.zip)); // Zip
                    row.append($('<td>').text(record.country)); // Country
                    row.append($('<td>').text(record.balance)); // Balance
                    row.append($('<td>').text(record.company_id)); // Company ID
                    row.append($('<td>').html(record.button)); // Action buttons

                    tbody.append(row);
                });
            }
        });
    });
</script>-->
