<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  

class Supplier_model extends CI_Model {

     
   public function create($data = array())
	{
		$add_supplier =  $this->db->insert('supplier_information', $data);

		 $supplier_id = $this->db->insert_id();
        $coa = $this->headcode();
           if($coa->HeadCode!=NULL){
                $headcode=$coa->HeadCode+1;
           }else{
                $headcode="21110000001";
            }
    $c_acc=$supplier_id.'-'.$data['supplier_name'];
    $createby=$this->session->userdata('id');
    $createdate=date('Y-m-d H:i:s');
       

    $supplier_coa = [
             'HeadCode'        => $headcode,
            'HeadName'         => $c_acc,
            'PHeadName'        => 'Suppliers',
            'HeadLevel'        => '4',
            'IsActive'         => '1',
            'IsTransaction'    => '1',
            'IsGL'             => '0',
            'HeadType'         => 'L',
            'IsBudget'         => '0',
            'supplier_id'      => $supplier_id,
            'IsDepreciation'   => '0',
            'DepreciationRate' => '0',
            'CreateBy'         => $createby,
            'CreateDate'       => $createdate,
        ];
		
		 $this->db->insert('acc_coa', $supplier_coa);
    if ($this->db->affected_rows() <= 0) {
        log_message('error', 'Failed to insert supplier into acc_coa.');
        return false;
    }

        $sub_acc = [
            'subTypeId'   => 4,
            'name'        => $data['supplier_name'],
            'referenceNo' => $supplier_id,
            'status'      => 1,
            'created_date'=> date("Y-m-d"),
            
       ];

        if($add_supplier){
           
            $this->db->insert('acc_subcode',$sub_acc);
			 $acc_subcode_id = $this->db->insert_id();
        }
		
		
        if(!empty($this->input->post('previous_balance'))){
			           $supplier_accledger = array(
      'VNo'            =>  'OBTSup-' . $supplier_id,
      'Vtype'          =>  'Opening Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  $headcode,
      'Narration'      =>  'Opening Balance For supplier '.$data['supplier_name'],
      'Debit'          =>  $this->input->post('previous_balance', true),
      'Credit'         =>  0,
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1,
	  'subType'     => 4,
      'subCode'     => $acc_subcode_id, // $ شامل کیا گیا
	  'company_id'    => $this->input->post('company_id', TRUE)
    );
                         $cc = array(
      'VNo'            =>  'OBTS-' . $supplier_id,
      'Vtype'          =>  'Opening Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  111000001,
      'Narration'      =>  'Opening Balance  For supplier '.$data['supplier_name'].' Advance',
      'Debit'          =>  0,
      'Credit'         =>  $this->input->post('previous_balance', true),
      'IsPosted'       =>  1,
      'CreateBy'       =>  $this->session->userdata('id'),
      'CreateDate'     =>  date('Y-m-d H:i:s'),
      'IsAppove'       =>  1,
	   'subType'     => 4,
      'subCode'     => $acc_subcode_id, // $ شامل کیا گیا
	  'company_id'    => $this->input->post('company_id', TRUE)
    ); 
                  
       $this->db->insert('acc_transaction',$supplier_accledger);
       $this->db->insert('acc_transaction',$cc);
	     if ($this->db->affected_rows() <= 0) {
            log_message('error', 'Failed to insert supplier opening balance into acc_transaction.');
            return false;
        }
        
          }
        return true;
	}
	
	
	
	  //credit customer dropdown
	  
	 /*  public function bdtask_CheckCreditCustomerList(){

        $postData = $this->input->post();
        $data = $this->customer_model->getCreditCustomerList($postData);
        echo json_encode($data);
    } 

	  
	 
	 public function bdtask_CheckPaidCustomerList(){
        // GET data
        $postData = $this->input->post();
        $data = $this->customer_model->bdtask_getPaidCustomerList($postData);
        echo json_encode($data);
    } 

    public function bdtask_credit_customer_dropdown()
  {
    $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('supplier_information a')
      ->join('acc_coa b','a.supplier_id = b.supplier_id','left')
      ->having('balance > 0')
      ->group_by('a.supplier_id')
      ->order_by('a.supplier_name', 'asc')
      ->get()
      ->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->supplier_id] = $value->supplier_name;
      return $list;
    } else {
      return false; 
    }
  }


  // paid customer dropdown
   public function bdtask_paid_customer_dropdown()
  {
    $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('supplier_information a')
      ->join('acc_coa b','a.supplier_id = b.supplier_id','left')
      ->having('balance <= 0')
      ->group_by('a.supplier_id')
      ->order_by('a.supplier_name', 'asc')
      ->get()
      ->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->supplier_id] = $value->supplier_name;
      return $list;
    } else {
      return false; 
    }
  }
  
  
  
   public function bdtask_all_credit_customer(){

   return $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('supplier_information a')
      ->join('acc_coa b','a.supplier_id = b.supplier_id','left')
      ->having('balance > 0')
      ->group_by('a.supplier_id')
      ->order_by('a.supplier_name', 'asc')
      ->get()
      ->result();
  }

    public function bdtask_all_paid_customer(){

   return $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('supplier_information a')
      ->join('acc_coa b','a.supplier_id = b.supplier_id','left')
      ->having('balance <= 0')
      ->group_by('a.supplier_id')
      ->order_by('a.supplier_name', 'asc')
      ->get()
      ->result();
  }*/

	public function supplier_dropdown()
	{
		$data =  $this->db->select("*")
			->from('supplier_information')
			->order_by('supplier_name', 'asc')
			->get()
			->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->supplier_id] = $value->supplier_name;
      return $list;
    } else {
      return false; 
    }
	}





		public function supplier_list($offset=null, $limit=null)
    {
  

        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('supplier_information a')
			->join('acc_coa b','a.supplier_id = b.supplier_id','left')
			->group_by('a.supplier_id')
			->order_by('a.supplier_name', 'asc')
			->limit($offset, $limit)
			->get()
			->result();

         
    }


      

    public function getsupplierList($postData = null)
{
    $response = array();
    $supplier_id = $this->input->post('supplier_id');
    $custom_data = $this->input->post('customfiled');

    $sup_data = [];
    if (!empty($custom_data)) {
        foreach ($custom_data as $supd) {
            $sup_data[] = $supd;
        }
    }

    ## Read value
    $draw = $postData['draw'];
    $start = $postData['start'];
    $rowperpage = $postData['length']; // Rows display per page
    $columnIndex = $postData['order'][0]['column']; // Column index
    $columnName = $postData['columns'][$columnIndex]['data']; // Column name
    $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
    $searchValue = $postData['search']['value']; // Search value

    ## Search Query
    $searchQuery = "";
    if (!empty($searchValue)) {
        $searchQuery = " (
            s.supplier_name LIKE '%" . $searchValue . "%' 
            OR s.mobile LIKE '%" . $searchValue . "%' 
            OR s.emailnumber LIKE '%" . $searchValue . "%'
            OR s.phone LIKE '%" . $searchValue . "%' 
            OR s.address LIKE '%" . $searchValue . "%' 
            OR s.country LIKE '%" . $searchValue . "%' 
            OR s.state LIKE '%" . $searchValue . "%' 
            OR s.zip LIKE '%" . $searchValue . "%' 
            OR s.city LIKE '%" . $searchValue . "%'
        )";
    }

    ## Total number of records without filtering
    $this->db->select('COUNT(DISTINCT s.supplier_id) AS allcount');
    $this->db->from('supplier_information s');
    $this->db->join('acc_coa coa', 'coa.supplier_id = s.supplier_id', 'left');
    $this->db->join('acc_transaction at', 'at.COAID = coa.HeadCode', 'left');
    if (!empty($supplier_id)) {
        $this->db->where('s.supplier_id', $supplier_id);
    }
    if (!empty($sup_data)) {
        $this->db->where_in('s.supplier_id', $sup_data);
    }
    $totalRecords = $this->db->count_all_results();

    ## Total number of records with filtering
    $this->db->select('COUNT(DISTINCT s.supplier_id) AS allcount');
    $this->db->from('supplier_information s');
    $this->db->join('acc_coa coa', 'coa.supplier_id = s.supplier_id', 'left');
    $this->db->join('acc_transaction at', 'at.COAID = coa.HeadCode', 'left');
    if (!empty($supplier_id)) {
        $this->db->where('s.supplier_id', $supplier_id);
    }
    if (!empty($sup_data)) {
        $this->db->where_in('s.supplier_id', $sup_data);
    }
    if (!empty($searchQuery)) {
        $this->db->where($searchQuery);
    }
    $totalRecordwithFilter = $this->db->count_all_results();

    ## Fetch records
    $this->db->select("
        s.supplier_id,
		s.company_id,
        s.supplier_name,
		c.company_name,
        s.address,
        s.city,
        s.state,
        s.zip,
        s.country,
        s.mobile,
        s.emailnumber,
        s.phone,
        coa.HeadCode AS account_code,
        coa.HeadName AS account_name,
        SUM(CASE WHEN at.Debit > 0 THEN at.Debit ELSE 0 END) AS total_debit,
        SUM(CASE WHEN at.Credit > 0 THEN at.Credit ELSE 0 END) AS total_credit,
        (SUM(CASE WHEN at.Debit > 0 THEN at.Debit ELSE 0 END) - 
         SUM(CASE WHEN at.Credit > 0 THEN at.Credit ELSE 0 END)) AS balance,
        pur_data.TotalPaidAmount,
        pur_data.TotalDueAmount,
        purchase_data.TotalPurchases
    ");
    $this->db->from('supplier_information s');
    $this->db->join('acc_coa coa', 'coa.supplier_id = s.supplier_id', 'left');
    $this->db->join('acc_transaction at', 'at.COAID = coa.HeadCode', 'left');
    $this->db->join("(SELECT supplier_id, 
                     SUM(paid_amount) AS TotalPaidAmount, 
                     SUM(due_amount) AS TotalDueAmount 
                 FROM product_purchase 
                 GROUP BY supplier_id
                 ) AS pur_data", 
                 'pur_data.supplier_id = s.supplier_id', 
                 'left');
    $this->db->join("(SELECT 
                     supplier_id, 
                     COUNT(DISTINCT purchase_id) AS TotalPurchases
                 FROM product_purchase
                 GROUP BY supplier_id
                 ) AS purchase_data",
                 'purchase_data.supplier_id = s.supplier_id',
                 'left');
	$this->db->join('company_information c', 'c.company_id = s.company_id', 'left'); // Join with company_information

    if (!empty($supplier_id)) {
        $this->db->where('s.supplier_id', $supplier_id);
    }
    if (!empty($sup_data)) {
        $this->db->where_in('s.supplier_id', $sup_data);
    }

    $this->db->group_by('s.supplier_id, coa.HeadCode, coa.HeadName');
    $this->db->order_by('s.supplier_name', 'ASC');
    $records = $this->db->get()->result();

    ## Prepare Response Data
    $data = array();
    $sl = 1 + $start;

    foreach ($records as $record) {
        $button = '';
          $base_url = base_url();
 
          if($this->permission1->method('manage_supplier','update')->access()){
              $button .=' <a href="'.$base_url.'edit_supplier/'.$record->supplier_id.'" class="btn btn-info btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="left" title="Update"><i class="pe-7s-note" aria-hidden="true"></i></a>';
            }
        if($this->permission1->method('manage_supplier','delete')->access()){
            $button .=' <a onclick="supplierdelete('.$record->supplier_id.')" href="javascript:void(0)"  class="btn btn-danger btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="right" title="Delete "><i class="pe-7s-trash" aria-hidden="true"></i></a>';
        }


        $data[] = array(
            'sl' => $sl,
			'supplier_name' => $record->supplier_name,
			'company_names' => $record->company_name,
            'address' => $record->address,
            'mobile' => $record->mobile,
            'email' => $record->emailnumber,
            'city' => $record->city,
            'state' => $record->state,
            'zip' => $record->zip,
            'country' => $record->country,
            'purchase_no' => $record->TotalPurchases, // Include Total Purchases
            'paid_ammount' => number_format($record->TotalPaidAmount, 2),
            'due_amount' => number_format($record->TotalDueAmount, 2),
            'debit_plus' => number_format($record->total_debit, 2),
            'credit_minus' => number_format($record->total_credit, 2),
            'balance' => number_format($record->balance, 2),
            'button' => $button,
        );
        $sl++;
    }

    ## Response
    $response = array(
        "draw" => intval($draw),
        "iTotalRecords" => $totalRecords,
        "iTotalDisplayRecords" => $totalRecordwithFilter,
        "aaData" => $data
    );

    return $response;
}



        
    
    public function individual_info($id){
      return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('supplier_information a')
      ->join('acc_coa b','a.supplier_id = b.supplier_id','left')
      ->where('a.supplier_id',$id)
      ->group_by('a.supplier_id')
      ->order_by('a.supplier_name', 'asc')
      ->get()
      ->result();
    }






	public function singledata($id = null)
	{
		return $this->db->select('*')
			->from('supplier_information')
			->where('supplier_id', $id)
			->get()
			->row();
	}

  public function allsupplier()
  {
    return $this->db->select('*')
      ->from('supplier_information')
      ->get()
      ->result();
  }




	public function update($data = array())
	{
		$updatesupplier =  $this->db->where('supplier_id', $data["supplier_id"])
			->update("supplier_information", $data);

		$supplier_id = $data["supplier_id"];
        $old_headnam = $supplier_id.'-'.$this->input->post("old_name");
        $c_acc=$supplier_id.'-'.$data["supplier_name"];
         $supplier_coa = [
             'HeadName'         => $c_acc
        ];
 

        $sub_acc = [
            'name'        => $data['supplier_name'],
          ];

        $this->db->where('referenceNo', $supplier_id)
                 ->where('subTypeId', 4)
                 ->update('acc_subcode',$sub_acc);
    
    return true;
	}
	
	
	
	
	
	
	
	
	
	
	

	public function delete($id = null)
	{

        $this->db->where('referenceNo', $id)
                 ->where('subTypeId', 4)
                 ->delete('acc_subcode');

		return $this->db->where('supplier_id', $id)
			->delete("supplier_information");
	}


	   public function headcode(){
         $query=$this->db->query("SELECT MAX(HeadCode) as HeadCode FROM acc_coa WHERE HeadLevel='4' And HeadCode LIKE '21110%'");
        return $query->row();

    }


      public function previous_balance_add($balance, $supplier_id) {
    $cusifo = $this->db->select('*')->from('supplier_information')->where('supplier_id',$supplier_id)->get()->row();
    $headn = $supplier_id.'-'.$cusifo->supplier_name;
    $coainfo = $this->db->select('*')->from('acc_coa')->where('HeadName',$headn)->get()->row();
    $supplier_headcode = $coainfo->HeadCode;
        $transaction_id = $this->generator(10);
       

// supplier debit for previous balance
      $cosdr = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'PR Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  $supplier_headcode,
      'Narration'      =>  'supplier debit For '.$cusifo->supplier_name,
      'Debit'          =>  $balance,
      'Credit'         =>  0,
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    );
       $inventory = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'PR Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  1141,
      'Narration'      =>  'Inventory credit For Old sale For'.$cusifo->supplier_name,
      'Debit'          =>  0,
      'Credit'         =>  $balance,//purchase price asbe
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    ); 

       
        if(!empty($balance)){
           $this->db->insert('acc_transaction', $cosdr); 
           $this->db->insert('acc_transaction', $inventory); 
        }
    }



public function generator($lenth)
    {
        $number=array("A","B","C","D","E","F","G","H","I","J","K","L","N","M","O","P","Q","R","S","U","V","T","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0");
    
        for($i=0; $i<$lenth; $i++)
        {
            $rand_value=rand(0,34);
            $rand_number=$number["$rand_value"];
        
            if(empty($con))
            { 
            $con=$rand_number;
            }
            else
            {
            $con="$con"."$rand_number";}
        }
        return $con;
    }


          public function supplier_ledgerdata($per_page, $page) {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where('b.PHeadName','Suppliers');
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
         
            return $query->result_array();
        }
        return false;
    }

        
        public function count_supplier_ledger() {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where('b.PHeadName','Suppliers');
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }
  

      public function supplier_list_ledger() {
        $this->db->select('*');
        $this->db->from('supplier_information');
        $this->db->order_by('supplier_name', 'asc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        public function supplier_personal_data($supplier_id) {
        $this->db->select('*');
        $this->db->from('supplier_information');
        $this->db->where('supplier_id', $supplier_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

         public function supplierledger_searchdata($supplier_id, $start, $end) {
    // Log inputs for debugging
    log_message('debug', "Supplier ID: $supplier_id, Start Date: $start, End Date: $end");

    // Build the query
    $this->db->select('a.*, b.HeadName');
    $this->db->from('acc_transaction a');
    $this->db->join('acc_coa b', 'a.COAID = b.HeadCode');

    // Add supplier_id filter
    $this->db->where('b.supplier_id', $supplier_id);

    // Add date filters only if values are provided
    if (!empty($start)) {
        $this->db->where('a.VDate >=', $start);
    }
    if (!empty($end)) {
        $this->db->where('a.VDate <=', $end);
    }

    // Add approval filter
    $this->db->where('a.IsAppove', 1);

    // Add ordering
    $this->db->order_by('a.VDate', 'desc');

    // Execute query
    $query = $this->db->get();

    // Log the generated query
    log_message('debug', 'Generated Query: ' . $this->db->last_query());

    // Check for results
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }

    return false;
}


        public function supplier_list_advance(){
        $this->db->select('*');
        $this->db->from('supplier_information');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        public function advance_details($transaction_id,$supplier_id){

        $headcode = $this->db->select('HeadCode')->from('acc_coa')->where('supplier_id',$supplier_id)->get()->row();
        return $data  = $this->db->select('*')
                        ->from('acc_transaction')
                        ->where('VNo',$transaction_id)
                        ->where('COAID',$headcode->HeadCode)
                        ->get()
                        ->result_array();

    }

        public function supplier_product_sale_info($supplier_id) {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where('b.supplier_id',$supplier_id);
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }
	
	
	
	
		
	//irfan get all company data
   // Fetch all company data from the database
   
   
    public function getAllCompanies() {
        $query = $this->db->get('company_information'); // Replace with your table name
        return $query->result(); // Return result as an array of objects
    }
	
	
	

//irfan end
	
	
	

}

